import { PersonalDetails } from './personalDetails';

describe('PersonalDetails', () => {
  it('should create an instance', () => {
    expect(new PersonalDetails()).toBeTruthy();
  });
});
