export class PersonalDetails {
  id : number=0;
  username: string='';
  dob : string='';
  gender : string = '';
  address : string = '';
  fathername : string ='';
  mothername : string = '';
  name:string='';
 // username:string='';
  email:string='';
}
