export class User {
  name: string ="";
  username: string ="" ;
  email: string ="";
  password: string ="";
 isadmin:string ="";
}

// export class Users {
//   user: any[] = [];
// }


export class personalusers{
  id:number=0;
  username:string ='';
  email:string ='';
  dob:string ='';
  gender:string='';
  address:string='';
  fathername:string ='';
  mothername:string ='';  
  name:string='';  
};