export class doctors {
  docdes: string = '';
  docdep: string = '';
  docexp: number = 0;
  docname: string = '';
  id: number = 0;
  availfrom: string = '';
  availto: string = '';
  contact: string = "";
  slot1: string = '';
  slot2: string = '';
  slot3: string = '';
  slot4: string = '';
  slot5: string = '';

  // "slot1":this.slot1
  // "slot2":this.slot2
  // "slot3":this.slot3
  // "slot4":this.slot4
  // "slot5":this.slot5

}
