export class appdetail{
aid: number =0;
pid: Number=0;
pname: string='';
address: string='';
docname:string ='';
date:string='';
disease:string='';
gender:string='';
mail:string='';
pphone:string='';
room:string='';
ptype:string='';
}

export class appdetails {

  appdetail1: any[] = [];

}
