import { Rooms } from './rooms';

describe('Rooms', () => {
  it('should create an instance', () => {
    expect(new Rooms()).toBeTruthy();
  });
});
