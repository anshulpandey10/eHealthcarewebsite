export class Rooms {
  rid : number=0;
  status : string='';
  rent : number=0;
  floor : number=0;
}
