export class inpat {
    ipaddress: string='';
    ipdisease: string='';
    ipdoa: string='';
    ipgender: string='';
    ipid: number =0;
    ipmail: string='';
    ipname: string='';
    ipphone:string='';
    iproom: number=0;
    ipmarital: string='';
    ippincode: string='';
    ipmedicine: string='';
    floor:number=0;
    username:string='';
  }

