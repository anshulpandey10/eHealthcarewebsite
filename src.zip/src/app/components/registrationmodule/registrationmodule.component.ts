import { Component } from '@angular/core';

@Component({
  selector: 'app-registrationmodule',
  templateUrl: './registrationmodule.component.html',
  styleUrls: ['./registrationmodule.component.css']
})
export class RegistrationmoduleComponent {

}
